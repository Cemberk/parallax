# GPU DiffDbg v0.1.0

A differential debugger for CUDA kernels. Identifies exactly where two GPU
executions diverge - like `rr` for GPUs.

## Quick Start

```bash
# 1. Add to PATH
export PATH=$PATH:$(pwd)/bin

# 2. Compile your kernel with instrumentation
clang++ -fpass-plugin=lib/libGpuDiffDbgPass.so \
    -I include/ \
    -L lib/ -lgddbg_runtime -lcudart \
    -o my_kernel my_kernel.cu

# 3. Run twice, compare
gddbg check ./my_kernel
```

## Components

| File | Description |
|------|-------------|
| `lib/libGpuDiffDbgPass.so` | LLVM compiler plugin (auto-instruments branches) |
| `lib/libgddbg_runtime.a` | CUDA runtime library (records traces) |
| `bin/gddbg-diff` | Differential analysis CLI (Rust) |
| `bin/gddbg` | Workflow driver (Python) |
| `include/` | Headers for manual instrumentation |
| `examples/` | Validation scenarios |

## Selective Instrumentation

### Compile-Time Filter (Zero Overhead)
Only instrument specific functions:
```bash
GDDBG_FILTER="compute_attention,matmul_*" clang++ -fpass-plugin=lib/libGpuDiffDbgPass.so ...
```

### Runtime ROI Toggle
Enable/disable recording from kernel code:
```cuda
__global__ void my_kernel(...) {
    // Only record when something looks wrong
    if (error_metric > threshold) {
        gddbg_enable();
    }

    // ... code under investigation ...

    gddbg_disable();
}
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `GDDBG_TRACE` | `trace.gddbg` | Output trace file path |
| `GDDBG_FILTER` | (none) | Comma-separated function name patterns |
| `GDDBG_SITES` | `gddbg-sites.json` | Site table output path |
| `GDDBG_ENABLED` | `1` | Set to `0` to disable tracing |
| `GDDBG_BUFFER_SIZE` | `4096` | Events per warp buffer |

## Commands

```bash
gddbg diff <trace_a> <trace_b>              # Compare two traces
gddbg diff <trace_a> <trace_b> --map sites.json  # With source locations
gddbg run ./binary                           # Run with tracing
gddbg check ./binary                         # Run twice and auto-diff
```

## Requirements

- CUDA Toolkit 11.0+
- LLVM 18 (for compiler plugin)
- Python 3.8+ (for driver script)
- Linux x86_64
